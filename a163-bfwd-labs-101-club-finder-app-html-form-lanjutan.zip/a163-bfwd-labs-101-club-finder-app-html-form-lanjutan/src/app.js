import home from './script/view/home.js';

document.addEventListener('DOMContentLoaded', () => {
  home();
});
